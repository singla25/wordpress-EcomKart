<?php
/**
 * Template Name: Landing / Custom Page
 */

get_header(); ?>

<?php 

echo  do_shortcode('[questionnaire_form id="19"]');
?>

<?php get_footer(); ?>
